import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Project{
    public static void main(String[] args) {
        if(args.length < 1){
            System.out.println("File not found!!");
            return;
        }
        String fileName = args[0];
        readDataFromFile(fileName);
        ArrayList<Student> studentList = readDataFromFile();
        ArrayList<Student> sortedByAge = Student.sortByAge(new ArrayList<>(studentList));
        ArrayList<Student> sortedByCGPA = Student.sortByCGPA(new ArrayList<>(studentList));
        ArrayList<Student> sortedBySID = Student.sortBySID(new ArrayList<>(studentList));
        ArrayList<Student> sortedByFirstName = Student.sortByFirstName(new ArrayList<>(studentList));
        printList(studentList, "Unsorted List");
        printList(sortedBySID, "sorted List By SID");
        printList(sortedByAge, "sorted List By Age");
        printList(sortedByCGPA, "sorted List By CGPA");
        printList(sortedByFirstName, "sorted List By First Name");
        Iterator<Student> studentListIterator = studentList.iterator();
        double averageAge = 0, averageCGPA = 0;
        int count = 0;

        while(studentListIterator.hasNext()){
            Student student = studentListIterator.next();
            averageCGPA += student.getCgpa();
            averageAge += student.getAge();
            count++;
        }
        averageAge /= count;
        averageCGPA /= count;
        System.out.printf("Average Age = %.2f\tAverage CGPA = %.2f", averageAge, averageCGPA);
        printContentOfErrorFile();

    }

    private static void readDataFromFile(String path) {
        try (Scanner readDataFile = new Scanner(new BufferedReader(new FileReader(path)))) {
            ObjectOutputStream validRecords = new ObjectOutputStream(new FileOutputStream("StudentData.ser"));
            PrintWriter inValidRecords = new PrintWriter(new BufferedWriter(new FileWriter("ErrorMsgs.txt")));
            while (readDataFile.hasNext()) {
                // Reading and Tokenizing Records
                String record = readDataFile.nextLine();
                String[] fields = record.split(",");
                // ArrayList : Validations contains boolean values returned from matcher method for each class in order

                ArrayList<Boolean> validations = ValidPatterns.matchAllFields(fields);
                boolean studentRecordIsValid = isStudentRecordValid(validations);
                if (studentRecordIsValid) {
                    Student student = createInstanceOfStudent(fields);
                    validRecords.writeObject(student);
                } else {
                    StringBuilder errorString = new StringBuilder();
                    ArrayList<String> labels = getLabels();//Error Labels
                    ArrayList<Integer> indexes = getIndexes(); // Indexes of field array.
                    Iterator<Boolean> booleanIterator = validations.iterator();//List of validations(Boolean Values) of all the fields for every record
                    Iterator<String> labelIterator = labels.iterator();
                    Iterator<Integer> indexIterator = indexes.iterator();
                    while (booleanIterator.hasNext() && labelIterator.hasNext() && indexIterator.hasNext()) {
                        if (!booleanIterator.next()) {
                            errorString.append(labelIterator.next()).append(fields[indexIterator.next()]).append("\n");
                        } else {
                            labelIterator.next();
                            indexIterator.next();
                        }

                    }
                    errorString.append("lINE: ").append(record).append(" contains wrong data");
                    inValidRecords.println(errorString);

                }

            }
            validRecords.close();
            inValidRecords.close();
        } catch (IOException e) {
            e.getStackTrace();
            System.out.println(e.getMessage());
        }
    }
    private static ArrayList<Student> readDataFromFile(){
        ArrayList<Student> studentList = new ArrayList<>();
        try(ObjectInputStream studentFile = new ObjectInputStream(new BufferedInputStream(new FileInputStream("StudentData.ser")))){
            boolean eof = false;
            while(!eof){
                try{
                    Student student = (Student) studentFile.readObject();
                    studentList.add(student);
                }catch(EOFException e){
                    eof = true;
                }
            }
        }catch(IOException e){
            System.out.println("IO Exception " + e.getMessage());
        }catch(ClassNotFoundException e){
            System.out.println("Class not Found Exception " + e.getMessage());
        }
        return studentList;
    }

    private static boolean isStudentRecordValid(ArrayList<Boolean> validations) {
        return validations.get(0) && validations.get(1) && validations.get(2) && validations.get(3) && validations.get(4) && validations.get(5) && validations.get(6);
    }

    private static Student createInstanceOfStudent(String[] fields) {
        String studentID = fields[0];
        String firstName = fields[1];
        String lastName = fields[2];
        String cnic = fields[3];
        int age = Integer.parseInt(fields[4]);
        double cgpa = Double.parseDouble(fields[5]);
        String emailID = fields[6];
        return new Student(studentID, firstName, lastName, cnic, age, cgpa, emailID);
    }

    private static ArrayList<String> getLabels() {
        ArrayList<String> labels = new ArrayList<>();
        labels.add("Incorrect SID: ");
        labels.add("Invalid First Name: ");
        labels.add("Invalid Last Name: ");
        labels.add("Incorrect CNIC: ");
        labels.add("Incorrect Age: ");
        labels.add("Incorrect CGPA: ");
        labels.add("Incorrect EmailId: ");
        return labels;
    }

    private static ArrayList<Integer> getIndexes() {
        ArrayList<Integer> indexes = new ArrayList<>();
        indexes.add(0);
        indexes.add(1);
        indexes.add(2);
        indexes.add(3);
        indexes.add(4);
        indexes.add(5);
        indexes.add(6);
        return indexes;
    }
    private static void printList(ArrayList<Student> studentList, String string){
        System.out.println("Here is " + string);
        for (Student student: studentList) {
            System.out.println(student.toString());
        }
        System.out.println("\n\n_____________________________________________________________________________________________\n\n");
    }
    private static void printContentOfErrorFile(){
        System.out.println("\n____________________________________________________________________________\n");
        System.out.println("The contents of the ErrorMsgs.txt file are as follows:\n");
        try(Scanner scanner = new Scanner(new BufferedReader(new FileReader("ErrorMsgs.txt")))){
            while(scanner.hasNext()){
                System.out.println(scanner.nextLine());
            }
        }catch(IOException e){
            e.getStackTrace();
        }
    }
}
class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    private String studentID;
    private String firstName;
    private String lastName;
    private String cnic;
    private int age;
    private double cgpa;
    private String emailID;

    public Student(String studentID, String firstName, String lastName, String cnic, int age, double cgpa, String emailID) {
        this.studentID = studentID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.cnic = cnic;
        this.age = age;
        this.cgpa = cgpa;
        this.emailID = emailID;
    }

    public int getAge() {
        return age;
    }

    public double getCgpa() {
        return cgpa;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getFirstName() {
        return firstName;
    }

    @Override
    public String toString(){
        return String.format("%12s\t%12s\t%12s\t%12s\t%d\t%.2f\t%12s\n", studentID, firstName, lastName, cnic, age, cgpa, emailID);
    }
    public static ArrayList<Student> sortByAge(ArrayList<Student> studentList){
        for (int i = 0; i < studentList.size(); i++) {
            for (int j = i+1; j < studentList.size(); j++) {
                if (studentList.get(i).getAge() > studentList.get(j).getAge()){
                    Student temp = studentList.get(j);
                    studentList.remove(j);
                    studentList.add(j, studentList.get(i));
                    studentList.remove(i);
                    studentList.add(i, temp);
                }
            }
        }
        return studentList;
    }
    public static ArrayList<Student> sortByCGPA(ArrayList<Student> studentList){
        for (int i = 0; i < studentList.size(); i++) {
            for (int j = i+1; j < studentList.size(); j++) {
                if (studentList.get(i).getCgpa() < studentList.get(j).getCgpa()){
                    Student temp = studentList.get(j);
                    studentList.remove(j);
                    studentList.add(j, studentList.get(i));
                    studentList.remove(i);
                    studentList.add(i, temp);
                }
            }
        }
        return studentList;
    }
    public static ArrayList<Student> sortBySID(ArrayList<Student> studentList){
        for (int i = 0; i < studentList.size(); i++) {
            for (int j = i+1; j < studentList.size(); j++) {
                if ((studentList.get(i).getStudentID().compareTo(studentList.get(j).getStudentID())) > 0){
                    Student temp = studentList.get(j);
                    studentList.remove(j);
                    studentList.add(j, studentList.get(i));
                    studentList.remove(i);
                    studentList.add(i, temp);
                }
            }
        }
        return studentList;
    }
    public static ArrayList<Student> sortByFirstName(ArrayList<Student> studentList){
        for (int i = 0; i < studentList.size(); i++) {
            for (int j = i+1; j < studentList.size(); j++) {
                if ((studentList.get(i).getFirstName().compareTo(studentList.get(j).getFirstName())) > 0){
                    Student temp = studentList.get(j);
                    studentList.remove(j);
                    studentList.add(j, studentList.get(i));
                    studentList.remove(i);
                    studentList.add(i, temp);
                }
            }
        }
        return studentList;
    }
}
class ValidPatterns {
    public static final Pattern STUDENT_ID=Pattern.compile("(?i)(FA|SP)\\d\\d-[B|Mb|m][A-Za-z][A-Za-z]-\\d\\d\\d");
    public static final Pattern FIRST_NAME= Pattern.compile("[A-Z][a-zA-Z]*");
    public static final Pattern LAST_NAME=Pattern.compile("[A-Z][a-zA-Z]*");
    public static final Pattern AGE = Pattern.compile("\\d{2}");
    public static final Pattern CNIC= Pattern.compile("\\d{5}-\\d{7}-\\d");
    public static final Pattern EMAIL= Pattern.compile("(?i)(FA|SP)\\d\\d-[B|Mb|m][A-Za-z][A-Za-z]-\\d\\d\\d(@cuilahore.edu.pk)");
    public static final Pattern CGPA= Pattern.compile("([0-3].[0-9][0-9])|([0-4].00)");

    public static boolean matchID(String studentID){
        Matcher matcher = STUDENT_ID.matcher(studentID);
        return matcher.matches();
    }
    public static boolean matchFirstName(String firstName){
        Matcher matcher = FIRST_NAME.matcher(firstName);
        return matcher.matches();
    }
    public static boolean matchLastName(String lastName){
        Matcher matcher = LAST_NAME.matcher(lastName);
        return matcher.matches();
    }
    public static boolean matchAge(String age){
        Matcher matcher = AGE.matcher(age);
        return matcher.matches();
    }
    public static boolean matchCNIC(String cnic){
        Matcher matcher = CNIC.matcher(cnic);
        return matcher.matches();
    }
    public static boolean matchEmail(String email){
        Matcher matcher = EMAIL.matcher(email);
        return matcher.matches();
    }
    public static boolean matchCGPA(String cgpa){
        Matcher matcher = CGPA.matcher(cgpa);
        return matcher.matches();
    }
    public static ArrayList<Boolean> matchAllFields(String[] fields){
        ArrayList<Boolean> validations = new ArrayList<>();
        validations.add(matchID(fields[0]));
        validations.add(matchFirstName(fields[1]));
        validations.add(matchLastName(fields[2]));
        validations.add(matchCNIC(fields[3]));
        validations.add(matchAge(fields[4]));
        validations.add(matchCGPA(fields[5]));
        validations.add(matchEmail(fields[6]));
        return validations;
    }
}

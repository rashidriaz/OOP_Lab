// Author : Rashid Riaz CIIT/FA19_BSE_081/LHR 
//============================================================================
import java.util.concurrent.TimeUnit;
import java.util.Scanner;

//============================================================================
public class Simpletron {
	// ============================================================================
	// Read / Write
	private static final int readFromKeyboard = 10;
	private static final int writeOnScreen = 11;
	// ============================================================================
	// Load/Store
	private static final int loadFromMemory = 20;
	private static final int storeFromAccumulator = 21;
	// ============================================================================
	// Arithmetic Operations
	private static final int performAddition = 30;
	private static final int performSubtraction = 31;
	private static final int performDivision = 32;
	private static final int performMultiplication = 33;
	// ============================================================================
	// TransferOfControl
	private static final int branchToMemoryLocation = 40;
	private static final int branchToLocationIfAccumulatorIsNegative = 41;
	private static final int branchToLocationIfAccumulatorIsZero = 42;
	private static final int EndOfExecution = 43;
	// ============================================================================
	// Memory Array
	private static int[] ramMemory = new int[100];
	// ============================================================================
	// Registers
	private static int accumulator = 0;
	private static int operationCode = 0;
	private static int operand = 0;
	private static int instructionRegister = 0;
	private static int instructionCounter = -1;
	// ============================================================================
	// Scanner
	private static Scanner input = new Scanner(System.in);

	// ============================================================================
	public static void main(String[] args) throws InterruptedException {

		if (args.length < 1) {
			System.out.println("Error!! Command Line Arguments not Found!\n");
		} else {

			parseCommandLineArguments(args);
			if (startExecution()) {
				clearScreen(0);
				showRegistersValues();
				showMemoryInformation();
				System.out.println("\nExecution Terminated with the exit Code : 0");
			} else {
				clearScreen(0);
				showRegistersValues();
				showMemoryInformation();
				System.out.println("\nError!! Operation code : " + operationCode + ", is invalid!!");
			}

		}
	}

	// ============================================================================
	private static void parseCommandLineArguments(String[] args) {
		for (int i = 0; i < args.length; i++) {
			try {
				ramMemory[i] = Integer.parseInt(args[i]);
			} catch (NumberFormatException e) {
				System.out.println(e);
				System.out.printf("\nCommand Line Argument number %d = %s\n", (i + 1), args[i]);
			}
		}
	}

	// ============================================================================
	public static boolean startExecution() throws InterruptedException {
		do {
			clearScreen(0);
			showRegistersValues();
			showMemoryInformation();
			System.out.print("\nPress Enter Key to continue...");
			input.nextLine();
			clearScreen(0);
			instructionCounter++;
			instructionRegister = ramMemory[instructionCounter];
			operationCode = instructionRegister / 100;
			operand = instructionRegister % 100;
			performOperation();
		} while (!(operationCode == EndOfExecution) && checkCommandsValidity());

		if (operationCode != 43) {
			operationCode = instructionRegister / 100;
			operand = instructionRegister % 100;
			return false;
		}
		return true;
	}

	// ============================================================================
	private static void performOperation() throws InterruptedException {
		switch (operationCode) {

			case readFromKeyboard:
				ramMemory[operand] = readFromKeyboard();
				break;

			case writeOnScreen:
				writeOnScreen();
				break;

			case loadFromMemory:
				accumulator = ramMemory[operand];
				break;

			case storeFromAccumulator:
				ramMemory[operand] = accumulator;
				break;

			case performAddition:
				accumulator += ramMemory[operand];
				break;

			case performSubtraction:
				accumulator -= ramMemory[operand];
				break;

			case performMultiplication:
				accumulator *= ramMemory[operand];
				break;

			case performDivision:
				accumulator = ramMemory[operand] / accumulator;
				break;

			case branchToMemoryLocation:
				instructionCounter = operand - 1;
				break;

			case branchToLocationIfAccumulatorIsZero:
				if (accumulator == 0) {
					instructionCounter = operand - 1;
				}
				break;

			case branchToLocationIfAccumulatorIsNegative:
				if (accumulator < 0) {
					instructionCounter = operand - 1;
				}
				break;
		}
	}

	// ============================================================================
	private static int readFromKeyboard() {
		System.out.print("\nEnter Number : ");
		int number = 0;
		try {
			number = Integer.parseInt(input.nextLine());
		} catch (NumberFormatException e) {
			System.out.println(e);
			number = readFromKeyboard();
		}
		return number;
	}

	// ============================================================================
	private static void writeOnScreen() throws InterruptedException {
		System.out.println("Instruction at Memory Location : " + operand + ", is : " + ramMemory[operand]);
		System.out.print("\nPress Enter to continue...");
		input.nextLine();
		clearScreen(0);
	}

	// ============================================================================
	public static void showMemoryInformation() {
		System.out.print(
				"\n_________________________________________________________________________________________________\n\n  \t");
		for (int i = 0; i < 10; i++) {
			System.out.printf(" %4d \t", i);
		}
		System.out.println("\n");
		for (int i = 0; i < ramMemory.length; i += 10) {
			System.out.printf("%4d| \t", i);
			for (int j = 0; j < 10; j++) {
				System.out.printf(" %4d \t", ramMemory[i + j]);
			}
			System.out.println("\n");
		}

	}

	// ============================================================================
	public static void showRegistersValues() {
		System.out.println("\nRegisters\n");
		System.out.println("Accumulator : " + accumulator);
		System.out.println("Instruction Register : " + instructionRegister);
		System.out.println("Instruction Count : " + (instructionCounter + 1));
		System.out.println("Operation Code : " + operationCode);
		System.out.println("Operand : " + operand);

	}

	// ============================================================================
	private static boolean checkCommandsValidity() {
		boolean read = (operationCode == readFromKeyboard);
		boolean write = (operationCode == writeOnScreen);
		boolean load = (operationCode == loadFromMemory);
		boolean store = (operationCode == storeFromAccumulator);
		boolean add = (operationCode == performAddition);
		boolean subtract = (operationCode == performSubtraction);
		boolean multiply = (operationCode == performMultiplication);
		boolean divide = (operationCode == performDivision);
		boolean branch = (operationCode == branchToMemoryLocation);
		boolean branchNeg = (operationCode == branchToLocationIfAccumulatorIsNegative);
		boolean branchZero = (operationCode == branchToLocationIfAccumulatorIsZero);
		boolean halt = (operationCode == EndOfExecution);

		if (read || write || load || store || add || subtract || divide || multiply || branch || branchNeg
				|| branchZero || halt) {
			return true;
		}
		return false;
	}

	// ============================================================================
	public static void clearScreen(int time) throws InterruptedException {
		TimeUnit.SECONDS.sleep(time);
		System.out.println("\033\143");
	}
	// ============================================================================
}

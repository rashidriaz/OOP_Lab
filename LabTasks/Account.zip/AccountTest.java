public class AccountTest
{
	public static void main(String[] args)
	{
		Account account = new Account("jane green", 50.0);
		System.out.printf("Initial Account Balance : %.2f \n", account.getBalance());
		double depositAmount = 25.0;
		System.out.printf("\n Adding %.2f to Account Balance \n\n", depositAmount);
		account.deposit(depositAmount);
		System.out.printf("New Account Balancce : %.2f", account.getBalance());
	}
}

/*
 *   Copyright (c) 2020 
 * Author : Rashid Riaz - FA19-BSE-081
 *   All rights reserved.
 */
import java.security.SecureRandom;

public class Craps {

	private static final SecureRandom randomNumbers = new SecureRandom();

	private enum Status {
		CONTINUE, WON, LOST
	};

	private static final int SNAKE_EYES = 2;
	private static final int TREY = 3;
	private static final int SEVEN = 7;
	private static final int YO_LEVEN = 11;
	private static final int BOX_CARS = 12;

	private static int gamblerWins = 0;
	private static int gamblerRollWins = 0;
	private static int gamblerBalance = 0;
	private static int casinoWins = 0;
	private static int casinoRollWins = 0;
	private static int casinoBalance = 0;

	public static void main(String[] args) {

		for (int i = 1; i <= 9000000; i++) {

			firstRoll(rollDice(), betAmount());
		}
		showResults();
	}

	public static int betAmount() {

		return (50 + randomNumbers.nextInt(51));
	}

	public static int rollDice() {

		int die1 = 1 + randomNumbers.nextInt(6);
		int die2 = 1 + randomNumbers.nextInt(6);
		int sum = die1 + die2;
		return sum;
	}

	public static void firstRoll(int sumOfDice, int gambleAmount) {

		int myPoint = 0;
		Status gameStatus;
		switch (sumOfDice) {

			case SEVEN:
			case YO_LEVEN:

				gameStatus = Status.WON;
				gamblerRollWins++;
				gamblerWins++;
				gamblerBalance += gambleAmount;
				casinoBalance -= gambleAmount;
				break;

			case SNAKE_EYES:
			case TREY:
			case BOX_CARS:
				gameStatus = Status.WON;
				casinoRollWins++;
				casinoWins++;
				casinoBalance += gambleAmount;
				gamblerBalance -= gambleAmount;
				break;

			default:

				gameStatus = Status.CONTINUE;
				myPoint = sumOfDice;
				nextRolls(gameStatus, myPoint, gambleAmount);
				break;
		}
	}

	public static void nextRolls(Status gameStatus, int myPoint, int gambleAmount) {

		while (gameStatus == Status.CONTINUE) {
			int sumOfDice = rollDice();

			if (sumOfDice == myPoint) {
				gameStatus = Status.WON;
				gamblerWins++;
				gamblerBalance += gambleAmount;
				casinoBalance -= gambleAmount;
			} else if (sumOfDice == SEVEN) {
				gameStatus = Status.LOST;
				casinoWins++;
				casinoBalance += gambleAmount;
				gamblerBalance -= gambleAmount;
			}

		}
	}

	public static void showResults() {
		System.out.println("\n\n________________________________________________________\n");
		System.out.print("Gambler Wins : " + gamblerWins + " Times");
		System.out.println(", Casino Wins : " + casinoWins + " Times");
		System.out.println("\n\n________________________________________________________\n");
		System.out.println("First Roll wins for Gambler " + gamblerRollWins);
		System.out.println("\nFirst Roll wins for Casino : " + casinoRollWins);
		System.out.println("\n\n________________________________________________________\n");

		System.out.println("Gambler has Rs. " + gamblerBalance);
		System.out.println("\nCasino has Rs. " + casinoBalance);
	}

}

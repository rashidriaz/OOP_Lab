//Rashid Riaz _ CIIT/FA19_BSE_081/LHR
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FinalLab {
    public static void main(String[] args) {
        if (args.length < 1){
            System.out.println("File not Found");
            return;
        }
        String fileName = args[0];
        readDataFromFile(fileName);
        ArrayList<Vehicle> vehicleArrayList = readDataFromFile();
        ArrayList<Vehicle> sortedByRegistrationNumber = sortByRegistrationNumber(new ArrayList<>(vehicleArrayList));
        ArrayList<Vehicle> sortedByEngineCapacity = sortByEngineCapacity(new ArrayList<>(vehicleArrayList));
        ArrayList<Vehicle> sortedByYearOfManufacturing = sortByYearOfManufacturing(new ArrayList<>(vehicleArrayList));
        printList(vehicleArrayList, "Unsorted List");
        printList(sortedByRegistrationNumber, "sorted List By Registration number");
        printList(sortedByEngineCapacity, "sorted List By Engine Capacity");
        printList(sortedByYearOfManufacturing, "sorted List By Year of Manufacturing");
        Iterator<Vehicle> vehicleListIterator = vehicleArrayList.iterator();
        double averageEngineCapacity = 0;
        int count = 0;

        while(vehicleListIterator.hasNext()){
            Vehicle vehicle = vehicleListIterator.next();
            averageEngineCapacity += vehicle.getEngineCapacity();
            count++;
        }
        averageEngineCapacity /= count;
        System.out.printf("Average Engine Capacity = %.2f", averageEngineCapacity);
        printContentOfErrorFile();

    }

    private static void readDataFromFile(String path) {
        try (Scanner readDataFile = new Scanner(new BufferedReader(new FileReader(path)))) {
            ObjectOutputStream validRecords = new ObjectOutputStream(new FileOutputStream("VehicleData.ser"));
            PrintWriter inValidRecords = new PrintWriter(new BufferedWriter(new FileWriter("ErrorMsgs.txt")));
            while (readDataFile.hasNext()) {
                // Reading and Tokenizing Records
                String record = readDataFile.nextLine();
                String[] fields = record.split(",");
                // ArrayList : Validations contains boolean values returned from matcher method for each class in order

                ArrayList<Boolean> validations = ValidPatterns.matchAllFields(fields);
                boolean RecordIsValid = isRecordValid(validations);
                if (RecordIsValid) {
                    Vehicle vehicle;
                    if (fields[0].equalsIgnoreCase("car")){
                        vehicle = new Car(fields[1], Integer.parseInt(fields[2]), fields[3], Integer.parseInt(fields[4]));
                    }else if (fields[0].equalsIgnoreCase("Motercycle")){
                        vehicle = new MoterCycle(fields[1], Integer.parseInt(fields[2]), fields[3], Integer.parseInt(fields[4]));
                    }else{
                        vehicle = new Truck(fields[1], Integer.parseInt(fields[2]), fields[3], Integer.parseInt(fields[4]));
                    }
                    validRecords.writeObject(vehicle);
                } else {
                    StringBuilder errorString = new StringBuilder();
                    ArrayList<String> labels = getLabels();//Error Labels
                    ArrayList<Integer> indexes = getIndexes(); // Indexes of field array.
                    Iterator<Boolean> booleanIterator = validations.iterator();//List of validations(Boolean Values) of all the fields for every record
                    Iterator<String> labelIterator = labels.iterator();
                    Iterator<Integer> indexIterator = indexes.iterator();
                    while (booleanIterator.hasNext() && labelIterator.hasNext() && indexIterator.hasNext()) {
                        if (!booleanIterator.next()) {
                            errorString.append(labelIterator.next()).append(fields[indexIterator.next()]).append("\n");
                        } else {
                            labelIterator.next();
                            indexIterator.next();
                        }

                    }
                    errorString.append("lINE: ").append(record).append(" contains wrong data");
                    inValidRecords.println(errorString);

                }

            }
            validRecords.close();
            inValidRecords.close();
        } catch (IOException e) {
            e.getStackTrace();
            System.out.println(e.getMessage());
        }
    }
    private static ArrayList<Vehicle> readDataFromFile(){
        ArrayList<Vehicle> vehicleList = new ArrayList<>();
        try(ObjectInputStream vehicleFile = new ObjectInputStream(new BufferedInputStream(new FileInputStream("VehicleData.ser")))){
            boolean endOfFile = false;
            while(!endOfFile){
                try{
                    Vehicle vehicle = (Vehicle) vehicleFile.readObject();
                    vehicleList.add(vehicle);
                }catch(EOFException e){
                    endOfFile = true;
                }
            }
        }catch(IOException e){
            System.out.println("IO Exception " + e.getMessage());
        }catch(ClassNotFoundException e){
            System.out.println("Class not Found Exception " + e.getMessage());
        }
        return vehicleList;
    }
    private static boolean isRecordValid(ArrayList<Boolean> validations) {
        return validations.get(0) && validations.get(1) && validations.get(2) && validations.get(3) && validations.get(4);
    }
    private static ArrayList<String> getLabels() {
        ArrayList<String> labels = new ArrayList<>();
        labels.add("Incorrect Vehicle Type: ");
        labels.add("Invalid Registration Number: ");
        labels.add("Invalid Engine Capacity: ");
        labels.add("Incorrect Color: ");
        labels.add("Incorrect Year of Manufacturing: ");
        return labels;
    }
    private static ArrayList<Integer> getIndexes() {
        ArrayList<Integer> indexes = new ArrayList<>();
        indexes.add(0);
        indexes.add(1);
        indexes.add(2);
        indexes.add(3);
        indexes.add(4);
        return indexes;
    }

    public static ArrayList<Vehicle> sortByRegistrationNumber(ArrayList<Vehicle> vehicleList){
        for (int i = 0; i < vehicleList.size(); i++) {
            for (int j = i + 1; j < vehicleList.size(); j++) {
                if ((vehicleList.get(i).getRegistrationNumber().compareTo(vehicleList.get(j).getRegistrationNumber())) > 0){
                    Vehicle temp = vehicleList.get(j);
                    vehicleList.remove(j);
                    vehicleList.add(j, vehicleList.get(i));
                    vehicleList.remove(i);
                    vehicleList.add(i, temp);
                }
            }
        }
        return vehicleList;
    }
    public static ArrayList<Vehicle> sortByEngineCapacity(ArrayList<Vehicle> vehicleList){
        for (int i = 0; i < vehicleList.size(); i++) {
            for (int j = i+1; j < vehicleList.size(); j++) {
                if (vehicleList.get(i).getEngineCapacity() > vehicleList.get(j).getEngineCapacity()){
                    Vehicle temp = vehicleList.get(j);
                    vehicleList.remove(j);
                    vehicleList.add(j, vehicleList.get(i));
                    vehicleList.remove(i);
                    vehicleList.add(i, temp);
                }
            }
        }
        return vehicleList;
    }
    public static ArrayList<Vehicle> sortByYearOfManufacturing(ArrayList<Vehicle> vehicleList){
        for (int i = 0; i < vehicleList.size(); i++) {
            for (int j = i+1; j < vehicleList.size(); j++) {
                if (vehicleList.get(i).getYearOfManufacturing() < vehicleList.get(j).getYearOfManufacturing()){
                    Vehicle temp = vehicleList.get(j);
                    vehicleList.remove(j);
                    vehicleList.add(j, vehicleList.get(i));
                    vehicleList.remove(i);
                    vehicleList.add(i, temp);
                }
            }
        }
        return vehicleList;
    }

    private static void printList(ArrayList<Vehicle> vehicleList, String string){
        System.out.println("Here is " + string);
        for (Vehicle vehicle: vehicleList) {
            System.out.println(vehicle.toString());
        }
        System.out.println("\n\n_____________________________________________________________________________________________\n\n");
    }
    private static void printContentOfErrorFile(){
        System.out.println("\n____________________________________________________________________________\n");
        System.out.println("The contents of the ErrorMsgs.txt file are as follows:\n");
        try(Scanner scanner = new Scanner(new BufferedReader(new FileReader("ErrorMsgs.txt")))){
            while(scanner.hasNext()){
                System.out.println(scanner.nextLine());
            }
        }catch(IOException e){
            e.getStackTrace();
        }
    }

}
abstract  class Vehicle implements Serializable{
    private final long SerialVersionUID= 1;
    private String typeOfVehicle;
    private String RegistrationNumber;
    private int engineCapacity;
    private String color;
    private int yearOfManufacturing;

    public Vehicle(){}
    public Vehicle(String typeOfVehicle, String registrationNumber, int engineCapacity,String color, int yearOfManufacturing) {
        this.typeOfVehicle = typeOfVehicle;
        this.RegistrationNumber = registrationNumber;
        this.engineCapacity = engineCapacity;
        this.yearOfManufacturing = yearOfManufacturing;
        this.color = color;
    }

    public String getTypeOfVehicle() {
        return typeOfVehicle;
    }

    public void setTypeOfVehicle(String typeOfVehicle) {
        this.typeOfVehicle = typeOfVehicle;
    }

    public String getRegistrationNumber() {
        return RegistrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        RegistrationNumber = registrationNumber;
    }

    public int getEngineCapacity() {
        return engineCapacity;
    }

    public void setEngineCapacity(int engineCapacity) {
        this.engineCapacity = engineCapacity;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getYearOfManufacturing() {
        return yearOfManufacturing;
    }

    public void setYearOfManufacturing(int yearOfManufacturing) {
        this.yearOfManufacturing = yearOfManufacturing;
    }
    public abstract String toString();
}
class MoterCycle extends Vehicle implements Serializable {
    private final long serialVersionUID = 1;

    public MoterCycle() {
    }

    public MoterCycle(String registrationNumber, int engineCapacity, String color, int yearOfManufacturing) {
        super("MoterCycle", registrationNumber, engineCapacity, color, yearOfManufacturing);
    }
    public String toString(){
        return String.format("%10s\t%11s\t%4d\t%4s\t%2d", "MotorCycle", getRegistrationNumber(), getEngineCapacity(),getColor(), getYearOfManufacturing());
    }
}
class Car extends Vehicle implements Serializable {
    private final long serialVersionUID = 1;

    public Car() {
    }

    public Car(String registrationNumber, int engineCapacity, String color, int yearOfManufacturing) {
        super("Car", registrationNumber, engineCapacity, color, yearOfManufacturing);
    }

    public String toString(){
        return String.format("%10s\t%11s\t%4d\t%4s\t%2d", "Car", getRegistrationNumber(), getEngineCapacity(), getColor(),getYearOfManufacturing());
    }
}
class Truck extends Vehicle implements Serializable {
    private final long serialVersionUID = 1;

    public Truck() {
    }

    public Truck(String registrationNumber, int engineCapacity, String color, int yearOfManufacturing) {
        super("Truck", registrationNumber, engineCapacity, color, yearOfManufacturing);
    }
    public String toString(){
        return String.format("%10s\t%11s\t%4d\t%4s\t%2d", "Truck", getRegistrationNumber(), getEngineCapacity(), getColor(),getYearOfManufacturing());
    }
}
class ValidPatterns {
    public static final Pattern REGISTRATION_NUMBER=Pattern.compile("L[A-Z]{2}-\\d{2}-\\d{1,4}");
    public static final Pattern VEHICLE_TYPE= Pattern.compile("(MoterCycle|Car|Truck)");
    public static final Pattern COLOR = Pattern.compile("(Red|Black|Blue)");
    public static final Pattern ENGINE_CAPACITY= Pattern.compile("\\d{2,4}");
    public static final Pattern YEAR_OF_MANUFACTURING = Pattern.compile("\\d{2}");

    public static boolean matchRegistrationNumber(String registrationNumber){
        Matcher matcher = REGISTRATION_NUMBER.matcher(registrationNumber);
        return matcher.matches();
    }
    public static boolean matchVehiceType(String vehicleType){
        Matcher matcher = VEHICLE_TYPE.matcher(vehicleType);
        return matcher.matches();
    }
    public static boolean matchColor(String color){
        Matcher matcher = COLOR.matcher(color);
        return matcher.matches();
    }
    public static boolean matchEngineCapacity(String engineCapacity){
        Matcher matcher = ENGINE_CAPACITY.matcher(engineCapacity);
        return matcher.matches();
    }
    public static boolean matchYearOfManufacturing(String yearOfManufacturing){
        Matcher matcher = YEAR_OF_MANUFACTURING.matcher(yearOfManufacturing);
        return matcher.matches();
    }
    public static ArrayList<Boolean> matchAllFields(String[] fields){
        ArrayList<Boolean> validations = new ArrayList<>();
        validations.add(matchVehiceType(fields[0]));
        validations.add(matchRegistrationNumber(fields[1]));
        validations.add(matchEngineCapacity(fields[2]));
        validations.add(matchColor(fields[3]));
        validations.add(matchYearOfManufacturing(fields[4]));
        return validations;
    }
}
